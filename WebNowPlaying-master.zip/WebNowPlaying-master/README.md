### The WebNowPlaying Rainmeter plugin has been rewritten to take advantage of the new adapter library for easier implementation. The source code for the new version can be found [here](https://github.com/keifufu/WebNowPlaying-Redux-Rainmeter)

Note: The new version is fully compatible with the old version and is a drop in update. All skins will continue to work as before with the new version
