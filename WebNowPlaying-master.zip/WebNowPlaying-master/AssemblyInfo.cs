﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyCopyright("© 2017 - Trevor Hamilton")]
[assembly: AssemblyVersion("0.5.0")]

// Do not change the entries below!
#if X64
[assembly: AssemblyInformationalVersion("3.0.2.2161 (64-bit)")]
#else
[assembly: AssemblyInformationalVersion("3.0.2.2161 (32-bit)")]
#endif
[assembly: AssemblyProduct("Rainmeter")]
